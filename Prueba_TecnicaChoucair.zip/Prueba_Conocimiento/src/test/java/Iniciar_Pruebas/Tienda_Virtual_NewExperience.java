package Iniciar_Pruebas;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Tienda_Virtual_NewExperience {
	
	private WebDriver driver;
	
	@Before
	public void setUp() {
		
		System.setProperty("webdriver.chrome.driver","./src/test/resources/chromedriver/chromedrive.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.google.com/");
		
	} 
	
	@Test
	public void testGooglePase() {
		WebElement searchbox = driver.findElement(By.name("q"));
		
		searchbox.clear();
		searchbox.sendKeys("automationpractice.com/index.php");
		searchbox.submit();
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		assertEquals("automationpractice.com/index.php - Google Search",driver.getTitle());
	}
	
	@After
	public void tearDown() {
		
		driver.quit();
	}
}
